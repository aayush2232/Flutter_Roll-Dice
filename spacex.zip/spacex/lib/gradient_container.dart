import 'dart:math';

import 'package:flutter/material.dart';
import 'package:spacex/dice_roller.dart';

const startAlignment = Alignment.topLeft;
const endAlignment = Alignment.bottomRight;

class GradientContainer extends StatelessWidget {
  GradientContainer(this.color1, this.color2, {super.key});
  final Color color1;
  final Color color2;
  var activeDiceImage = 'assets/images/dice-1.png';

  void RollDice() {
    var diceRoll = Random().nextInt(6) + 1;

    activeDiceImage = 'assets/images/dice-$diceRoll.png';
    print("Changing Image");
  }

  @override
  Widget build(context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color1, color2],
          begin: startAlignment,
          end: endAlignment,
        ),
      ),
      child: Center(
        child: DiceRoller(),
        //child: StyledText("RRR amber aur aaj si ye dosti dhram dham"),
      ),
    );
  }
}
