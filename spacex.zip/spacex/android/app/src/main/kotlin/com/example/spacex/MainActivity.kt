package com.example.spacex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
